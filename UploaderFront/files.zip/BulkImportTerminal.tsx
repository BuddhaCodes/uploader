'use client';

import { useEffect, useRef } from 'react';

/**
 * Terminal de carga — Bulk Import
 *
 * Puerto directo del componente original en HTML/CSS/JS vanilla.
 * Toda la lógica imperativa (fetch por chunks, polling de estado, animaciones
 * de las barras) se mantiene igual, pero en vez de usar document.getElementById
 * se usan refs de React, y el ciclo de vida se controla con useEffect para
 * limpiar intervalos y listeners al desmontar el componente.
 */
export default function BulkImportTerminal() {
  // ---- refs a los nodos del DOM que antes se buscaban con getElementById ----
  const dropzoneRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dzEmptyRef = useRef<HTMLDivElement>(null);
  const dzFileRef = useRef<HTMLDivElement>(null);
  const startBtnRef = useRef<HTMLButtonElement>(null);
  const pauseBtnRef = useRef<HTMLButtonElement>(null);
  const cancelBtnRef = useRef<HTMLButtonElement>(null);
  const uploadFillRef = useRef<HTMLDivElement>(null);
  const importFillRef = useRef<HTMLDivElement>(null);
  const uploadHeadRef = useRef<HTMLDivElement>(null);
  const importHeadRef = useRef<HTMLDivElement>(null);
  const uploadFigureRef = useRef<HTMLSpanElement>(null);
  const importFigureRef = useRef<HTMLSpanElement>(null);
  const statReceivedRef = useRef<HTMLDivElement>(null);
  const statProcessedRef = useRef<HTMLDivElement>(null);
  const statRowsRef = useRef<HTMLDivElement>(null);
  const statTimeRef = useRef<HTMLDivElement>(null);
  const statusPillRef = useRef<HTMLSpanElement>(null);
  const tableNameRef = useRef<HTMLSpanElement>(null);
  const idleNoteRef = useRef<HTMLDivElement>(null);
  const liveDotRef = useRef<HTMLSpanElement>(null);
  const apiBaseInputRef = useRef<HTMLInputElement>(null);
  const activityLogRef = useRef<HTMLDivElement>(null);
  const activityEmptyRef = useRef<HTMLDivElement | null>(null);
  const activityCountRef = useRef<HTMLSpanElement>(null);
  const recDotRef = useRef<HTMLSpanElement>(null);
  const fileNameRef = useRef<HTMLDivElement>(null);
  const fileSizeRef = useRef<HTMLDivElement>(null);
  const changeFileBtnRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const CHUNK_SIZE = 8 * 1024 * 1024; // 8MB
    const POLL_MS = 900;

    const dropzone = dropzoneRef.current!;
    const fileInput = fileInputRef.current!;
    const dzEmpty = dzEmptyRef.current!;
    const dzFile = dzFileRef.current!;
    const startBtn = startBtnRef.current!;
    const pauseBtn = pauseBtnRef.current!;
    const cancelBtn = cancelBtnRef.current!;
    const uploadFill = uploadFillRef.current!;
    const importFill = importFillRef.current!;
    const uploadHead = uploadHeadRef.current!;
    const importHead = importHeadRef.current!;
    const uploadFigure = uploadFigureRef.current!;
    const importFigure = importFigureRef.current!;
    const statReceived = statReceivedRef.current!;
    const statProcessed = statProcessedRef.current!;
    const statRows = statRowsRef.current!;
    const statTime = statTimeRef.current!;
    const statusPill = statusPillRef.current!;
    const tableNameEl = tableNameRef.current!;
    const idleNote = idleNoteRef.current!;
    const liveDot = liveDotRef.current!;
    const apiBaseInput = apiBaseInputRef.current!;
    const activityLog = activityLogRef.current!;
    const activityCountEl = activityCountRef.current!;
    const recDot = recDotRef.current!;

    let requestCount = 0;
    let lastRowsSeen = 0;
    let lastTableSeen: string | null = null;

    let file: File | null = null;
    let uploadId: string | null = null;
    let offset = 0;
    let paused = false;
    let cancelled = false;

    let pollTimer: ReturnType<typeof setInterval> | null = null;
    let startedAt = 0;
    let lastTick = { t: 0, bytes: 0 };
    let recDotTimer: ReturnType<typeof setTimeout> | undefined;

    // Si el input está vacío, cae al valor de NEXT_PUBLIC_API_BASE_URL (o mismo origen si tampoco existe).
    const envApiBase = (process.env.NEXT_PUBLIC_API_BASE_URL || '').trim().replace(/\/$/, '');
    const apiBase = () => apiBaseInput.value.trim().replace(/\/$/, '') || envApiBase;

    const fmtBytes = (n: number) => {
      if (!n || n <= 0) return '0 B';
      const u = ['B', 'KB', 'MB', 'GB', 'TB'];
      let i = 0;
      while (n >= 1024 && i < u.length - 1) {
        n /= 1024;
        i++;
      }
      return `${n.toFixed(i === 0 ? 0 : 1)} ${u[i]}`;
    };
    const fmtNum = (n: number) => Number(n || 0).toLocaleString('es-ES');
    const fmtTime = (s: number) => {
      const m = Math.floor(s / 60);
      const sec = Math.floor(s % 60);
      return `${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
    };

    // ---------- Log de actividad ----------
    function nowStamp() {
      const d = new Date();
      return d.toTimeString().slice(0, 8) + '.' + String(d.getMilliseconds()).padStart(3, '0');
    }

    function logActivity({
      method,
      path,
      status,
      level,
      meta,
    }: {
      method: string;
      path: string;
      status?: number | string;
      level?: 'ok' | 'warn' | 'err' | 'info';
      meta?: string;
    }) {
      if (activityEmptyRef.current) {
        activityEmptyRef.current.remove();
        activityEmptyRef.current = null;
      }
      requestCount++;
      activityCountEl.textContent = `${requestCount} requests`;
      recDot.classList.add('live');
      if (recDotTimer) clearTimeout(recDotTimer);
      recDotTimer = setTimeout(() => recDot.classList.remove('live'), 600);

      const resolvedLevel =
        level || (typeof status === 'number' ? (status < 300 ? 'ok' : status < 500 ? 'warn' : 'err') : 'ok');
      const line = document.createElement('div');
      line.className = 'log-line';
      line.innerHTML = `
        <span class="log-time">${nowStamp()}</span>
        <span class="log-method ${method.toLowerCase()}">${method}</span>
        <span class="log-path">${path}</span>
        <span class="log-status ${resolvedLevel}">${status ?? ''}</span>
        <span class="log-meta">${meta || ''}</span>
      `;
      activityLog.appendChild(line);
      while (activityLog.children.length > 200) activityLog.removeChild(activityLog.firstChild!);
      activityLog.scrollTop = activityLog.scrollHeight;
    }

    function pulseMarker(el: HTMLElement, pct: number) {
      el.style.left = Math.min(100, Math.max(0, pct)) + '%';
      el.classList.remove('pulse');
      void el.offsetWidth; // reinicia la animación aunque llegue otro pulso enseguida
      el.classList.add('pulse');
    }

    // ---------- Selección de archivo ----------
    const onDropzoneClick = (e: MouseEvent) => {
      if (!dzFile.contains(e.target as Node) || e.target === dropzone) fileInput.click();
    };
    const onChangeFileBtnClick = (e: MouseEvent) => {
      e.stopPropagation();
      fileInput.click();
    };
    const onFileInputChange = (e: Event) => {
      const target = e.target as HTMLInputElement;
      if (target.files && target.files[0]) selectFile(target.files[0]);
    };

    const onDragEnterOver = (e: DragEvent) => {
      e.preventDefault();
      dropzone.classList.add('drag');
    };
    const onDragLeaveOrDrop = (e: DragEvent) => {
      e.preventDefault();
      dropzone.classList.remove('drag');
    };
    const onDrop = (e: DragEvent) => {
      if (e.dataTransfer?.files[0]) selectFile(e.dataTransfer.files[0]);
    };

    dropzone.addEventListener('click', onDropzoneClick);
    changeFileBtnRef.current!.addEventListener('click', onChangeFileBtnClick);
    fileInput.addEventListener('change', onFileInputChange);
    dropzone.addEventListener('dragenter', onDragEnterOver);
    dropzone.addEventListener('dragover', onDragEnterOver);
    dropzone.addEventListener('dragleave', onDragLeaveOrDrop);
    dropzone.addEventListener('drop', onDragLeaveOrDrop);
    dropzone.addEventListener('drop', onDrop);

    function selectFile(f: File) {
      file = f;
      dzEmpty.style.display = 'none';
      dzFile.style.display = 'flex';
      dropzone.classList.add('has-file');
      fileNameRef.current!.textContent = f.name;
      fileSizeRef.current!.textContent = fmtBytes(f.size);
      startBtn.disabled = false;
      idleNote.textContent = 'Listo para iniciar';
    }

    // ---------- Controles ----------
    const onStartClick = () => startUpload();
    const onPauseClick = () => {
      paused = !paused;
      pauseBtn.textContent = paused ? 'Reanudar' : 'Pausar';
      setStatus(paused ? 'Pausado' : 'Subiendo', paused ? 'warn' : 'on');
    };
    const onCancelClick = async () => {
      cancelled = true;
      if (pollTimer) clearInterval(pollTimer);
      if (uploadId) {
        try {
          await fetch(`${apiBase()}/api/upload/${uploadId}/cancel`, { method: 'POST' });
        } catch (_) {
          /* noop */
        }
      }
      setStatus('Cancelado', 'err');
      liveDot.classList.remove('live');
      startBtn.disabled = false;
      pauseBtn.disabled = true;
      cancelBtn.disabled = true;
      idleNote.textContent = 'Carga cancelada — la tabla parcial fue eliminada';
      idleNote.style.display = 'block';
    };

    startBtn.addEventListener('click', onStartClick);
    pauseBtn.addEventListener('click', onPauseClick);
    cancelBtn.addEventListener('click', onCancelClick);

    function setStatus(text: string, cls?: string) {
      statusPill.textContent = text;
      statusPill.className = 'status-pill' + (cls ? ' ' + cls : '');
    }

    async function startUpload() {
      if (!file) return;
      cancelled = false;
      paused = false;
      offset = 0;
      startBtn.disabled = true;
      pauseBtn.disabled = false;
      cancelBtn.disabled = false;
      pauseBtn.textContent = 'Pausar';
      idleNote.style.display = 'none';
      liveDot.classList.add('live');
      startedAt = Date.now();
      lastTick = { t: startedAt, bytes: 0 };
      setStatus('Iniciando…', 'warn');

      try {
        const initRes = await fetch(`${apiBase()}/api/upload/init`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ fileName: file.name, totalBytes: file.size }),
        });
        if (!initRes.ok) throw new Error('init falló');
        const init = await initRes.json();
        uploadId = init.uploadId;
        offset = init.offsetToResumeFrom || 0;

        setStatus('Subiendo', 'on');
        pollStatus();
        pollTimer = setInterval(pollStatus, POLL_MS);
        await uploadLoop();
      } catch (err) {
        console.error(err);
        setStatus('Error', 'err');
        idleNote.textContent = 'No se pudo conectar con el backend — revisa el endpoint configurado abajo';
        idleNote.style.display = 'block';
        startBtn.disabled = false;
        pauseBtn.disabled = true;
        cancelBtn.disabled = true;
      }
    }

    async function uploadLoop() {
      const totalChunks = Math.max(1, Math.ceil(file!.size / CHUNK_SIZE));
      let chunkIndex = Math.floor(offset / CHUNK_SIZE);

      while (offset < file!.size && !cancelled) {
        if (paused) {
          await sleep(400);
          continue;
        }

        const chunkStart = offset;
        const chunk = file!.slice(offset, Math.min(offset + CHUNK_SIZE, file!.size));
        chunkIndex++;
        const t0 = performance.now();
        let res: Response;
        try {
          res = await fetch(`${apiBase()}/api/upload/${uploadId}/chunk?offset=${offset}`, {
            method: 'PUT',
            body: chunk,
          });
        } catch (err) {
          logActivity({
            method: 'PUT',
            path: `/chunk?offset=${chunkStart}`,
            status: '—',
            level: 'err',
            meta: 'sin conexión, reintentando…',
          });
          await sleep(1000);
          continue;
        }
        const ms = Math.round(performance.now() - t0);

        if (res.status === 409) {
          const { correctOffset } = await res.json();
          logActivity({
            method: 'PUT',
            path: `/chunk?offset=${chunkStart}`,
            status: 409,
            level: 'warn',
            meta: `re-sincronizando → ${fmtBytes(correctOffset)}`,
          });
          offset = correctOffset;
          continue;
        }
        if (!res.ok) {
          logActivity({
            method: 'PUT',
            path: `/chunk?offset=${chunkStart}`,
            status: res.status,
            level: 'err',
            meta: 'reintentando…',
          });
          await sleep(1000);
          continue;
        }

        const data = await res.json();
        offset = data.receivedBytes;
        logActivity({
          method: 'PUT',
          path: `/chunk?offset=${chunkStart}`,
          status: res.status,
          level: 'ok',
          meta: `chunk ${chunkIndex}/${totalChunks} · ${fmtBytes(chunk.size)} · ${ms}ms`,
        });
        updateUploadBar(offset, file!.size);
        pulseMarker(uploadHead, (offset / file!.size) * 100);
      }

      if (!cancelled) {
        const t0 = performance.now();
        const res = await fetch(`${apiBase()}/api/upload/${uploadId}/complete`, { method: 'POST' });
        logActivity({
          method: 'POST',
          path: '/complete',
          status: res.status,
          level: res.ok ? 'ok' : 'err',
          meta: `${Math.round(performance.now() - t0)}ms · subida terminada`,
        });
      }
    }

    function updateUploadBar(received: number, total: number) {
      const pct = total ? Math.min(100, (received / total) * 100) : 0;
      uploadFill.style.width = pct + '%';
      uploadFill.classList.toggle('moving', pct < 100 && !paused);

      const now = Date.now();
      const dt = (now - lastTick.t) / 1000;
      let speed = 0;
      if (dt > 0.5) {
        speed = (received - lastTick.bytes) / dt;
        lastTick = { t: now, bytes: received };
      }
      uploadFigure.innerHTML = `<b>${fmtBytes(received)}</b> / ${fmtBytes(total)} · ${fmtBytes(speed)}/s`;
      statReceived.textContent = fmtBytes(received);
    }

    async function pollStatus() {
      if (!uploadId) return;
      const t0 = performance.now();
      try {
        const res = await fetch(`${apiBase()}/api/upload/${uploadId}/status`);
        const ms = Math.round(performance.now() - t0);
        if (!res.ok) {
          logActivity({ method: 'GET', path: '/status', status: res.status, level: 'err' });
          return;
        }
        const s = await res.json();

        const rowsDelta = s.rowsInserted - lastRowsSeen;
        lastRowsSeen = s.rowsInserted;
        logActivity({
          method: 'GET',
          path: '/status',
          status: res.status,
          level: 'ok',
          meta: `${ms}ms · ${rowsDelta > 0 ? '+' + fmtNum(rowsDelta) + ' filas' : 'sin cambios'}`,
        });

        const importPct = s.receivedBytes ? Math.min(100, (s.processedBytes / s.receivedBytes) * 100) : 0;
        importFill.style.width = importPct + '%';
        importFill.classList.toggle('moving', importPct < 100 && s.status !== 'Finished');
        if (rowsDelta > 0) pulseMarker(importHead, importPct);
        else importHead.style.left = importPct + '%';

        statProcessed.textContent = fmtBytes(s.processedBytes);
        statRows.textContent = fmtNum(s.rowsInserted);
        importFigure.innerHTML = `<b>${fmtNum(s.rowsInserted)}</b> filas · ${fmtBytes(s.processedBytes)} procesados`;
        statTime.textContent = fmtTime((Date.now() - startedAt) / 1000);

        if (s.tableName && s.tableName !== lastTableSeen) {
          lastTableSeen = s.tableName;
          tableNameEl.innerHTML = `tabla: <b>${s.tableName}</b>`;
          logActivity({ method: 'INFO', path: 'Tabla creada en MySQL', level: 'info', meta: s.tableName });
        }

        if (s.status === 'Finished') {
          setStatus('Completado', 'on');
          liveDot.classList.remove('live');
          if (pollTimer) clearInterval(pollTimer);
          pauseBtn.disabled = true;
          cancelBtn.disabled = true;
          startBtn.disabled = false;
          uploadFill.classList.remove('moving');
          importFill.classList.remove('moving');
          logActivity({ method: 'INFO', path: 'Import finalizado', level: 'ok', meta: `${fmtNum(s.rowsInserted)} filas totales` });
        } else if (s.status === 'Error') {
          setStatus('Error en import', 'err');
          idleNote.textContent = s.errorMessage || 'Ocurrió un error durante el import';
          idleNote.style.display = 'block';
          if (pollTimer) clearInterval(pollTimer);
          liveDot.classList.remove('live');
          logActivity({ method: 'INFO', path: 'Import falló', level: 'err', meta: s.errorMessage || '' });
        } else if (s.status === 'Importing' || s.status === 'Completed') {
          if (!paused) setStatus('Importando', 'warn');
        }
      } catch (_) {
        logActivity({ method: 'GET', path: '/status', status: '—', level: 'err', meta: 'sin respuesta' });
      }
    }

    const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

    // ---------- limpieza al desmontar ----------
    return () => {
      cancelled = true;
      if (pollTimer) clearInterval(pollTimer);
      if (recDotTimer) clearTimeout(recDotTimer);
      dropzone.removeEventListener('click', onDropzoneClick);
      changeFileBtnRef.current?.removeEventListener('click', onChangeFileBtnClick);
      fileInput.removeEventListener('change', onFileInputChange);
      dropzone.removeEventListener('dragenter', onDragEnterOver);
      dropzone.removeEventListener('dragover', onDragEnterOver);
      dropzone.removeEventListener('dragleave', onDragLeaveOrDrop);
      dropzone.removeEventListener('drop', onDragLeaveOrDrop);
      dropzone.removeEventListener('drop', onDrop);
      startBtn.removeEventListener('click', onStartClick);
      pauseBtn.removeEventListener('click', onPauseClick);
      cancelBtn.removeEventListener('click', onCancelClick);
    };
  }, []);

  return (
    <div className="wrap">
      <div className="eyebrow">
        <span className="dot" ref={liveDotRef}></span> Bulk import terminal
      </div>
      <h1>
        Sube el archivo. <em>No esperes al final</em> para verlo en MySQL.
      </h1>
      <p className="sub">
        Carga por partes con reanudación automática. Mientras el archivo sigue subiendo, el backend ya está creando
        la tabla e insertando filas — dos rieles, un mismo viaje.
      </p>

      <div className="dropzone" ref={dropzoneRef}>
        <div ref={dzEmptyRef}>
          <div className="dz-icon">
            <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
              <path d="M12 16V4M12 4l-4 4M12 4l4 4" strokeLinecap="round" strokeLinejoin="round" />
              <path
                d="M4 16v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
          <div className="dz-title">Arrastra tu archivo aquí</div>
          <div className="dz-hint">
            o <kbd>clic</kbd> para elegir — funciona bien con archivos de varios GB
          </div>
        </div>
        <div className="file-row" ref={dzFileRef} style={{ display: 'none' }}>
          <div className="file-icon">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
              <path d="M14 2v6h6" />
            </svg>
          </div>
          <div className="file-meta">
            <div className="file-name" ref={fileNameRef}>
              —
            </div>
            <div className="file-size" ref={fileSizeRef}>
              —
            </div>
          </div>
          <button className="file-change" ref={changeFileBtnRef}>
            Cambiar
          </button>
        </div>
        <input type="file" ref={fileInputRef} />
      </div>

      <div className="controls">
        <button className="action btn-primary" ref={startBtnRef} disabled>
          Iniciar carga
        </button>
        <button className="action btn-ghost" ref={pauseBtnRef} disabled>
          Pausar
        </button>
        <button className="action btn-danger" ref={cancelBtnRef} disabled>
          Cancelar
        </button>
      </div>

      <div className="rails">
        <div className="rail">
          <div className="rail-head">
            <span className="rail-label upload">Subida</span>
            <span className="rail-figure" ref={uploadFigureRef}>
              <b>0 B</b> / 0 B · 0 MB/s
            </span>
          </div>
          <div className="track">
            <div className="fill upload" ref={uploadFillRef}></div>
            <div className="head-marker upload" ref={uploadHeadRef}></div>
          </div>
        </div>
        <div className="rail">
          <div className="rail-head">
            <span className="rail-label import">Import a MySQL</span>
            <span className="rail-figure" ref={importFigureRef}>
              <b>0</b> filas · 0 filas/s
            </span>
          </div>
          <div className="track">
            <div className="fill import" ref={importFillRef}></div>
            <div className="head-marker import" ref={importHeadRef}></div>
          </div>
        </div>

        <div className="stats-strip">
          <div className="stat">
            <div className="stat-label">Recibido</div>
            <div className="stat-value teal" ref={statReceivedRef}>
              0 B
            </div>
          </div>
          <div className="stat">
            <div className="stat-label">Procesado</div>
            <div className="stat-value amber" ref={statProcessedRef}>
              0 B
            </div>
          </div>
          <div className="stat">
            <div className="stat-label">Filas insertadas</div>
            <div className="stat-value" ref={statRowsRef}>
              0
            </div>
          </div>
          <div className="stat">
            <div className="stat-label">Tiempo</div>
            <div className="stat-value" ref={statTimeRef}>
              00:00
            </div>
          </div>
        </div>

        <div className="status-line">
          <span className="status-pill" ref={statusPillRef}>
            En espera
          </span>
          <span className="table-name" ref={tableNameRef}>
            &nbsp;
          </span>
        </div>
        <div className="idle-note" ref={idleNoteRef}>
          Elige un archivo para empezar
        </div>
      </div>

      <div className="activity">
        <div className="activity-head">
          <span className="activity-title">
            <span className="rec-dot" ref={recDotRef}></span> Actividad — requests en vivo
          </span>
          <span className="activity-count" ref={activityCountRef}>
            0 requests
          </span>
        </div>
        <div className="activity-log" ref={activityLogRef}>
          <div
            className="activity-empty"
            ref={(el) => {
              activityEmptyRef.current = el;
            }}
          >
            Cada chunk enviado y cada consulta de estado van a aparecer aquí
          </div>
        </div>
      </div>

      <details className="config">
        <summary>Endpoint del backend</summary>
        <div className="config-body">
          <input
            type="text"
            ref={apiBaseInputRef}
            defaultValue={process.env.NEXT_PUBLIC_API_BASE_URL || ''}
            placeholder="https://tu-backend.com  (vacío = mismo origen)"
          />
        </div>
      </details>

      <style jsx global>{`
        :root {
          --bg: #0b0f14;
          --panel: #12171f;
          --panel-2: #1a212b;
          --border: #242d39;
          --border-soft: #1d2530;
          --text: #e7edf4;
          --muted: #7c8a9c;
          --muted-2: #546174;
          --teal: #2dd4bf;
          --teal-dim: #164a44;
          --amber: #f2b705;
          --amber-dim: #4a3b0a;
          --red: #f2545b;
          --red-dim: #4a1e21;
          --blue: #5aa9e6;
          --blue-dim: #173654;
          --mono: 'IBM Plex Mono', ui-monospace, SFMono-Regular, Menlo, monospace;
          --sans: 'IBM Plex Sans', system-ui, -apple-system, sans-serif;
        }

        * {
          box-sizing: border-box;
        }
        html,
        body {
          height: 100%;
        }
        body {
          margin: 0;
          background: radial-gradient(ellipse 900px 500px at 15% -10%, rgba(45, 212, 191, 0.06), transparent),
            radial-gradient(ellipse 700px 500px at 100% 0%, rgba(242, 183, 5, 0.05), transparent), var(--bg);
          color: var(--text);
          font-family: var(--sans);
          min-height: 100vh;
        }

        .wrap {
          max-width: 860px;
          margin: 0 auto;
          padding: 48px 24px 80px;
        }

        .eyebrow {
          display: flex;
          align-items: center;
          gap: 10px;
          font-family: var(--mono);
          font-size: 12px;
          letter-spacing: 0.14em;
          color: var(--muted);
          text-transform: uppercase;
          margin-bottom: 18px;
        }
        .eyebrow .dot {
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: var(--muted-2);
          transition: background 0.3s, box-shadow 0.3s;
        }
        .eyebrow .dot.live {
          background: var(--teal);
          box-shadow: 0 0 0 3px var(--teal-dim);
        }

        h1 {
          font-size: clamp(28px, 4vw, 40px);
          line-height: 1.15;
          letter-spacing: -0.02em;
          margin: 0 0 10px;
          font-weight: 600;
        }
        h1 em {
          color: var(--teal);
          font-style: normal;
        }
        .sub {
          color: var(--muted);
          font-size: 15px;
          line-height: 1.6;
          max-width: 52ch;
          margin: 0 0 36px;
        }

        .dropzone {
          border: 1.5px dashed var(--border);
          border-radius: 14px;
          background: var(--panel);
          padding: 36px 28px;
          text-align: center;
          cursor: pointer;
          transition: border-color 0.2s, background 0.2s;
          position: relative;
        }
        .dropzone.drag {
          border-color: var(--teal);
          background: var(--panel-2);
        }
        .dropzone.has-file {
          text-align: left;
          cursor: default;
        }
        .dz-icon {
          width: 38px;
          height: 38px;
          margin: 0 auto 14px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: var(--muted-2);
        }
        .dz-title {
          font-size: 15px;
          font-weight: 500;
          margin-bottom: 4px;
        }
        .dz-hint {
          font-size: 13px;
          color: var(--muted);
          font-family: var(--mono);
        }
        .dz-hint kbd {
          background: var(--panel-2);
          border: 1px solid var(--border);
          border-radius: 4px;
          padding: 1px 6px;
          font-size: 12px;
        }
        input[type='file'] {
          display: none;
        }

        .file-row {
          display: flex;
          align-items: center;
          gap: 14px;
        }
        .file-icon {
          width: 44px;
          height: 44px;
          border-radius: 9px;
          flex-shrink: 0;
          background: var(--panel-2);
          border: 1px solid var(--border);
          display: flex;
          align-items: center;
          justify-content: center;
          color: var(--teal);
        }
        .file-meta {
          flex: 1;
          min-width: 0;
        }
        .file-name {
          font-size: 14.5px;
          font-weight: 500;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .file-size {
          font-family: var(--mono);
          font-size: 12.5px;
          color: var(--muted);
          margin-top: 2px;
        }
        .file-change {
          font-family: var(--mono);
          font-size: 12px;
          color: var(--muted);
          border: 1px solid var(--border);
          background: transparent;
          padding: 6px 12px;
          border-radius: 7px;
          cursor: pointer;
          white-space: nowrap;
        }
        .file-change:hover {
          color: var(--text);
          border-color: var(--muted-2);
        }

        .controls {
          display: flex;
          gap: 10px;
          margin: 20px 0 34px;
        }
        button.action {
          font-family: var(--sans);
          font-weight: 600;
          font-size: 14px;
          border-radius: 9px;
          padding: 11px 20px;
          border: 1px solid transparent;
          cursor: pointer;
          transition: filter 0.15s, opacity 0.15s, transform 0.05s;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        button.action:active {
          transform: scale(0.98);
        }
        button.action:disabled {
          opacity: 0.35;
          cursor: not-allowed;
        }
        .btn-primary {
          background: var(--teal);
          color: #052823;
        }
        .btn-primary:hover:not(:disabled) {
          filter: brightness(1.08);
        }
        .btn-ghost {
          background: var(--panel-2);
          color: var(--text);
          border-color: var(--border);
        }
        .btn-ghost:hover:not(:disabled) {
          border-color: var(--muted-2);
        }
        .btn-danger {
          background: transparent;
          color: var(--red);
          border-color: var(--red-dim);
        }
        .btn-danger:hover:not(:disabled) {
          background: var(--red-dim);
        }

        .rails {
          border: 1px solid var(--border);
          border-radius: 14px;
          background: var(--panel);
          padding: 26px 26px 22px;
        }
        .rail {
          margin-bottom: 22px;
        }
        .rail:last-child {
          margin-bottom: 0;
        }
        .rail-head {
          display: flex;
          justify-content: space-between;
          align-items: baseline;
          margin-bottom: 9px;
          font-family: var(--mono);
        }
        .rail-label {
          font-size: 11.5px;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          font-weight: 600;
        }
        .rail-label.upload {
          color: var(--teal);
        }
        .rail-label.import {
          color: var(--amber);
        }
        .rail-figure {
          font-size: 12.5px;
          color: var(--muted);
        }
        .rail-figure b {
          color: var(--text);
          font-weight: 600;
        }

        .track {
          height: 10px;
          border-radius: 6px;
          background: var(--panel-2);
          border: 1px solid var(--border-soft);
          overflow: hidden;
          position: relative;
        }
        .fill {
          height: 100%;
          border-radius: 6px;
          width: 0%;
          transition: width 0.25s ease-out;
          position: relative;
        }
        .fill.upload {
          background: linear-gradient(90deg, #1c8a7c, var(--teal));
        }
        .fill.import {
          background: linear-gradient(90deg, #a37a04, var(--amber));
        }
        .fill.moving::after {
          content: '';
          position: absolute;
          inset: 0;
          background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.35), transparent);
          width: 40px;
          animation: sheen 1.4s linear infinite;
        }
        @keyframes sheen {
          from {
            transform: translateX(-40px);
          }
          to {
            transform: translateX(220px);
          }
        }

        .head-marker {
          position: absolute;
          top: 50%;
          left: 0%;
          width: 9px;
          height: 9px;
          border-radius: 50%;
          transform: translate(-50%, -50%);
          transition: left 0.2s ease-out;
          pointer-events: none;
        }
        .head-marker.upload {
          background: var(--teal);
        }
        .head-marker.import {
          background: var(--amber);
        }
        .head-marker.pulse.upload {
          animation: pulseTeal 0.55s ease-out;
        }
        .head-marker.pulse.import {
          animation: pulseAmber 0.55s ease-out;
        }
        @keyframes pulseTeal {
          0% {
            box-shadow: 0 0 0 0 rgba(45, 212, 191, 0.55);
          }
          70% {
            box-shadow: 0 0 0 11px rgba(45, 212, 191, 0);
          }
          100% {
            box-shadow: 0 0 0 0 rgba(45, 212, 191, 0);
          }
        }
        @keyframes pulseAmber {
          0% {
            box-shadow: 0 0 0 0 rgba(242, 183, 5, 0.55);
          }
          70% {
            box-shadow: 0 0 0 11px rgba(242, 183, 5, 0);
          }
          100% {
            box-shadow: 0 0 0 0 rgba(242, 183, 5, 0);
          }
        }

        .stats-strip {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 0;
          margin-top: 24px;
          padding-top: 20px;
          border-top: 1px solid var(--border-soft);
        }
        .stat {
          text-align: left;
        }
        .stat-label {
          font-size: 11px;
          color: var(--muted);
          text-transform: uppercase;
          letter-spacing: 0.1em;
          margin-bottom: 6px;
          font-family: var(--mono);
        }
        .stat-value {
          font-family: var(--mono);
          font-size: 17px;
          font-weight: 600;
        }
        .stat-value.teal {
          color: var(--teal);
        }
        .stat-value.amber {
          color: var(--amber);
        }

        .status-line {
          margin-top: 20px;
          padding-top: 18px;
          border-top: 1px solid var(--border-soft);
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          font-family: var(--mono);
          font-size: 13px;
        }
        .status-pill {
          padding: 4px 11px;
          border-radius: 20px;
          font-size: 11.5px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.06em;
          background: var(--panel-2);
          color: var(--muted);
          border: 1px solid var(--border);
        }
        .status-pill.on {
          color: var(--teal);
          border-color: var(--teal-dim);
          background: rgba(45, 212, 191, 0.08);
        }
        .status-pill.warn {
          color: var(--amber);
          border-color: var(--amber-dim);
          background: rgba(242, 183, 5, 0.08);
        }
        .status-pill.err {
          color: var(--red);
          border-color: var(--red-dim);
          background: rgba(242, 84, 91, 0.08);
        }
        .table-name {
          color: var(--muted);
        }
        .table-name b {
          color: var(--text);
          font-weight: 500;
        }

        .idle-note {
          color: var(--muted-2);
          font-size: 13px;
          text-align: center;
          padding: 6px 0 2px;
          font-family: var(--mono);
        }

        .activity {
          margin-top: 16px;
          border: 1px solid var(--border);
          border-radius: 14px;
          background: var(--panel);
          overflow: hidden;
        }
        .activity-head {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 13px 20px;
          border-bottom: 1px solid var(--border-soft);
        }
        .activity-title {
          font-family: var(--mono);
          font-size: 11.5px;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          color: var(--muted);
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .activity-title .rec-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: var(--muted-2);
        }
        .activity-title .rec-dot.live {
          background: var(--red);
          animation: recBlink 1.4s ease-in-out infinite;
        }
        @keyframes recBlink {
          0%,
          100% {
            opacity: 1;
          }
          50% {
            opacity: 0.25;
          }
        }
        .activity-count {
          font-family: var(--mono);
          font-size: 11.5px;
          color: var(--muted-2);
        }

        .activity-log {
          height: 196px;
          overflow-y: auto;
          overflow-x: hidden;
          padding: 4px 18px;
          font-family: var(--mono);
          font-size: 12px;
          display: flex;
          flex-direction: column;
        }
        .activity-empty {
          color: var(--muted-2);
          font-size: 12.5px;
          text-align: center;
          padding: 78px 0;
          font-family: var(--mono);
        }
        .log-line {
          display: flex;
          gap: 12px;
          align-items: baseline;
          padding: 5px 0;
          border-bottom: 1px solid rgba(255, 255, 255, 0.02);
          opacity: 0;
          transform: translateY(2px);
          animation: logIn 0.2s ease-out forwards;
        }
        @keyframes logIn {
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .log-time {
          color: var(--muted-2);
          flex-shrink: 0;
          font-size: 11px;
        }
        .log-method {
          flex-shrink: 0;
          font-weight: 700;
          width: 34px;
          font-size: 11px;
          letter-spacing: 0.02em;
        }
        .log-method.put {
          color: var(--teal);
        }
        .log-method.post {
          color: var(--amber);
        }
        .log-method.get {
          color: var(--blue);
        }
        .log-method.info {
          color: var(--text);
        }
        .log-path {
          color: var(--muted);
          flex: 1;
          min-width: 0;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .log-status {
          flex-shrink: 0;
          font-weight: 700;
          font-size: 11px;
          width: 28px;
        }
        .log-status.ok {
          color: var(--teal);
        }
        .log-status.warn {
          color: var(--amber);
        }
        .log-status.err {
          color: var(--red);
        }
        .log-status.info {
          color: var(--blue);
        }
        .log-meta {
          color: var(--muted-2);
          flex-shrink: 0;
          font-size: 11px;
          max-width: 42%;
          text-align: right;
        }

        .activity-log::-webkit-scrollbar {
          width: 6px;
        }
        .activity-log::-webkit-scrollbar-thumb {
          background: var(--border);
          border-radius: 4px;
        }

        .config {
          margin-top: 28px;
          text-align: center;
        }
        .config summary {
          cursor: pointer;
          color: var(--muted-2);
          font-size: 12px;
          font-family: var(--mono);
          list-style: none;
          display: inline-block;
        }
        .config summary::-webkit-details-marker {
          display: none;
        }
        .config-body {
          margin-top: 12px;
          display: flex;
          gap: 8px;
          justify-content: center;
        }
        .config-body input {
          background: var(--panel-2);
          border: 1px solid var(--border);
          color: var(--text);
          font-family: var(--mono);
          font-size: 12.5px;
          padding: 8px 12px;
          border-radius: 8px;
          width: 320px;
        }
        .config-body input:focus {
          outline: none;
          border-color: var(--teal);
        }

        ::-webkit-scrollbar {
          width: 10px;
          height: 10px;
        }
        ::-webkit-scrollbar-thumb {
          background: var(--border);
          border-radius: 6px;
        }

        @media (max-width: 560px) {
          .stats-strip {
            grid-template-columns: repeat(2, 1fr);
            row-gap: 16px;
          }
          .controls {
            flex-wrap: wrap;
          }
        }

        @media (prefers-reduced-motion: reduce) {
          .fill,
          .eyebrow .dot {
            transition: none;
          }
          .fill.moving::after {
            animation: none;
          }
        }
      `}</style>
    </div>
  );
}
